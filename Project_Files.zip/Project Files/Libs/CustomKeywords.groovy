
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String



def static "custom_keywords_pack.customFunction.token"() {
    (new custom_keywords_pack.customFunction()).token()
}


def static "custom_keywords_pack.customFunction.issue"() {
    (new custom_keywords_pack.customFunction()).issue()
}


def static "custom_keywords_pack.customFunction.userName"(
    	String name	) {
    (new custom_keywords_pack.customFunction()).userName(
        	name)
}
