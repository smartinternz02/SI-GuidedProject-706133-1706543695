<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Amazon_Test_Suite_Custom_Keyword_Functions</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient>vp8687@srmist.edu.in;</mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>94889dc4-7a20-4c85-bdea-4872d367b66c</testSuiteGuid>
   <testCaseLink>
      <guid>f945b5f6-d16f-4ed8-8971-c6bc76484f99</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Custom_Keywords/Amazon_Custom_Keywords_001</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
</TestSuiteEntity>
